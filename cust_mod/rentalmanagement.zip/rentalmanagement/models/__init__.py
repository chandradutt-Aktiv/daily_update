# -*- coding: utf-8 -*-
from . import rental_type
from . import models
from . import p_template

